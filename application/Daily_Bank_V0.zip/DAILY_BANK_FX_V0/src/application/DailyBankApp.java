package application;

import application.control.DailyBankMainFrame;

public class DailyBankApp  {

	public static void main(String[] args) {

		DailyBankMainFrame.runApp();

	}
}
